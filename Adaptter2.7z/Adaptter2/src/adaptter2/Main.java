
package adaptter2;


public class Main {

    public static void main(String[] args) 
    {
 Adaptador miAdaptador = new Adaptador();
        
        miAdaptador.consignarPesos(50000000);
        System.out.println("Saldo de la cuenta de :"+(int)miAdaptador.getSaldoDolares()+" $USD");
        
        miAdaptador.retirarPesos(30000000);
        System.out.println("saldo de la cuenta : "+ (int)miAdaptador.getSaldoDolares()+" $USD");
    }
    
}
