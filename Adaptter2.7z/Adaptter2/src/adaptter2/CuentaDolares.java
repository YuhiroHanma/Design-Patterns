
package adaptter2;

public class CuentaDolares 
{
   private double dolares = 0;
  
    public CuentaDolares ()
    {
    
    }
    
    public double getSaldoDolares()
    {
        return this.dolares;
    }
    
    public void retirarDolares(double dolares)
    {
        this.dolares -= dolares;
    }
    
    public void consignarDolares(double dolares)
    {
        this.dolares += dolares;
    }
}
