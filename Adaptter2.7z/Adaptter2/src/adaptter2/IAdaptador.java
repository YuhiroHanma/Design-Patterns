package adaptter2;

public interface IAdaptador 
{
    public abstract void retirarPesos(double pesos);
    public abstract void consignarPesos(double pesos);
}
