
package adaptter2;

public class Adaptador extends CuentaDolares implements IAdaptador
{

    
    public Adaptador()
    {
    
    }
    
    @Override
    public void retirarPesos(double pesos) 
    {
        double dolares = pesos / 4404;
        this.retirarDolares(dolares);
    }

    @Override
    public void consignarPesos(double pesos) 
    {
      double dolares = pesos /4404;
      this.consignarDolares(dolares);  
        
    }
  
    
}
